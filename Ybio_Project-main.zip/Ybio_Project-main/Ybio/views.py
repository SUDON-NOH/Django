# 표준 라이브러리

# Core Django 라이브러리
from django.views.generic import TemplateView
# 아래의 뷰는 새로운 레코드를 생성하기 위해 이에 필요한 폼을 보여주고, 폼에 입력된 데이터로 테이블의 레코드를 생성해주는 뷰
from django.views.generic import CreateView
# User 모델의 객체를 생성하기 위해 보여주는 폼
# from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.mixins import LoginRequiredMixin, AccessMixin
# 인자로 url 패턴명을 받는다. url 패턴명을 인식하기 위해서는 urls.py 모듈이 메모리에 로딩되어야 함
from django.urls import reverse_lazy
from django.shortcuts import render, redirect
from django.conf import settings


# 외부 APP

# 내부 APP
from .forms import CustomUserCreationForm # User 모델의 객체를 생성하기 위해 보여주는 폼


# Home TemplateView
class HomeView(TemplateView):

	template_name = 'home.html'

	# Login 되어있는 상태에서는 contents 주소로 돌려보내는 로직
	def dispatch(self, request, *args, **kwargs):
		if request.user.is_authenticated:
			return redirect('contents')
		return super(HomeView, self).dispatch(request, *args, **kwargs)


# Contents TemplateView
class ContentsView(LoginRequiredMixin, TemplateView):
	template_name = 'contents.html'


# 인증 관련 View
class UserCreateView(CreateView):
	template_name = 'registration/register.html'
	# form_class = UserCreationForm
	form_class = CustomUserCreationForm
	success_url = reverse_lazy('register_done')


class UserCreateDoneTV(TemplateView):
	template_name = 'registration/register_done.html'


# Purchase home.css TemplateView
class PurchaseView(LoginRequiredMixin, TemplateView):
	template_name = 'purchase_home.html'


# Screening home.css TemplateView
class ScreeningView(LoginRequiredMixin, TemplateView):
	template_name = 'screening_home.html'


class OwnerOnlyMixin(AccessMixin):
	raise_exception = True
	permission_denied_message = "Owner Only Can Update/Delete the Object"


def dispatch(self, request, *args, **kwargs):
	obj = self.get_object()
	if request.user != obj.owner:
		return self.handle_no_permission()
	return super().dispatch(request, *args, **kwargs)