# Ybio.forms.py

# 표준 라이브러리

# Core Django 라이브러리
from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import get_user_model

# 외부 APP

# 내부 APP


class CustomUserCreationForm(UserCreationForm):

    username = forms.CharField(max_length=5, widget=forms.TextInput(attrs={'placeholder': 'ID'}))
    password1 = forms.CharField(widget=forms.PasswordInput, label="Password")
    password2 = forms.CharField(widget=forms.PasswordInput, label="Check PW")
    first_name = forms.CharField(widget=forms.TextInput(attrs={'placeholder': 'Name'}))
    email = forms.EmailField(widget=forms.TextInput(attrs={'placeholder': 'E-mail'}))
    team = forms.CharField(widget=forms.TextInput(attrs={'placeholder': 'Team'}))

    class Meta(UserCreationForm):
        model = get_user_model()
        fields = UserCreationForm.Meta.fields + ('team', 'email', 'first_name',)