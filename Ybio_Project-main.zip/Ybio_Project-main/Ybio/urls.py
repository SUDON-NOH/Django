"""Ybio URL Configuration
The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home.css, name='home.css')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home.css')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
# 표준 라이브러리

# Core Django 라이브러리
from django.urls import path
from django.contrib import admin
from django.conf.urls import include
from django.contrib.auth import views as auth_views

# 외부 APP

# 내부 APP
from Ybio.views import HomeView, PurchaseView, ScreeningView
from Ybio.views import UserCreateView, UserCreateDoneTV
from Ybio.views import ContentsView

urlpatterns = [
    path('admin/', admin.site.urls),
    # 인증 URL
    path('accounts/', include('django.contrib.auth.urls')),
    path('accounts/register/', UserCreateView.as_view(), name='register'),
    path('accounts/register/done/', UserCreateDoneTV.as_view(), name='register_done'),
    # HOME
    path('', HomeView.as_view(), name='home.css'),
    # CONTENTS
    path('contents/', ContentsView.as_view(), name='contents'),

    # PURCHASE
    # purchase_home
    path('purchase/', PurchaseView.as_view(), name='purchase'),
    # purchase_admin
    path('purchase/admin/', include('purchase_admin.urls')),
    # purchase_order
    path('purchase/order/', include('purchase_order.urls')),
    # purchase_board
    # path('purchase_board/', include('purchase_board.urls')),

    # SCREENING
    # screening
    path('screening/', ScreeningView.as_view(), name='screening'),
    # screening_analysis
    path('screening/analysis/', include('screening_analysis.urls')),
]