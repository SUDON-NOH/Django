from django.contrib import admin
from .models import customUser

# Register your models here.
@admin.register(customUser)
class customUserAdmin(admin.ModelAdmin):
    list_display = ('username', 'email', 'team', 'is_active', 'is_staff', 'last_login')
    list_filter = ('username',)
    search_fields = ('username', 'name', 'team', 'is_active')

