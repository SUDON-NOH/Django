# Core Django 라이브러리
from django.db import models
from django.contrib.auth.models import AbstractUser
# from django.contrib.auth.models import User


# Create your models here.

class customUser(AbstractUser):

    username = models.CharField('ID', max_length=5, primary_key=True)
    team = models.CharField('Team', max_length=20)
    email = models.EmailField()
    first_name = models.CharField('Name', max_length=10)
    last_name = models.CharField('Comment', max_length=10, blank=True)




