from django.apps import AppConfig


class PurchaseBoardConfig(AppConfig):
    name = 'purchase_board'
