import pandas as pd
from screening_analysis.models import screening_AG, screening_SA


file_route = 'Z:/ANRT/SIT/Django/SEARCH/'
file = ['REGI001AG(2.0).xlsx', 'REGI002SA(2.0).xlsx']


#######################################################################################################################
ex_file = pd.read_excel(file_route+file[0], sheet_name='M')

ex_file = ex_file.drop(ex_file.index[0:6])

ex_file = ex_file.drop(ex_file.columns[[0, 1, 2]], axis='columns')

ex_file = ex_file.drop(ex_file.index[0:711])

ex_file = ex_file.drop(ex_file.columns[[-1, -2, -3]], axis='columns')

# ex_file = ex_file.drop(ex_file.index[1000:])

ex_list = ex_file.values.tolist()

for i in ex_list:
    try:
        print(i)
        create_ag, is_ag = screening_AG.objects.get_or_create(
            agid=i[0],
            date=i[1],
            constructor=i[2],
            user=i[3],
            ag_name=i[4],
            gene=i[5],
            fid=i[6],
            vector=i[7],
            genevar=i[8],
            ld=i[9],
            dna=i[10],
            protein=i[11],
            wclone=i[12],
            structure=i[13],
            F=i[14],
            L=i[15],
            term=i[16],
            string=i[17]
        )
        if not is_ag:
            print('pass', i)
            pass
    except:
        pass

#######################################################################################################################
import pandas as pd
from screening_analysis.models import screening_AG


file_route = 'Z:/ANRT/SIT/Django/SEARCH/'
file = ['REGI001AG(2.0).xlsx', 'REGI002SA(2.0).xlsx']

ex_file = pd.read_excel(file_route+file[1], sheet_name='M')

ex_file = ex_file.drop(ex_file.index[0:6])

ex_file = ex_file.drop(ex_file.columns[[0, 1, 2, 3, 4, 5, 7, 8, ]], axis='columns')

# ex_file = ex_file.drop(ex_file.index[0:711])

# ex_file = ex_file.drop(ex_file.columns[[-1, -2, -3]], axis='columns')

# ex_file = ex_file.drop(ex_file.index[1000:])

ex_list = ex_file.values.tolist()

for i in ex_list:
    try:
        print(i[0])
        create_SA, is_SA = screening_SA.objects.get_or_create(
            sid=i[0],
            tar_id=i[1],
            tar_name=i[3],
            sa_name=i[2],
            isoheavy=i[4],
            isolight=i[5],
            vh=i[6],
            vl=i[7],
            ch=i[8],
            cl=i[9],
            heavey=i[10],
            light=i[11],
            modi=i[12],
            moc=i[13]
        )
        if not is_SA:
            pass
    except:
        pass

########################################################################################################################
import pandas as pd
from screening_analysis.models import target_table


file_route = 'Z:/ANRT/SIT/Django/참고/'
file = ['REGI104RD2.xlsx', ]
print(file[0])

ex_file = pd.read_excel(file_route + file[0], sheet_name='PAN')

ex_file = ex_file.drop(ex_file.index[0:6])

ex_file = ex_file.drop(ex_file.columns[[0, 1, 2, 5, 6, 7, 8, 9, 10, 11, 12, ]], axis='columns')

ex_list = ex_file.values.tolist()

for i in ex_list:
    try:
        print(i[0])
        target_id, is_target = target_table.objects.get_or_create(
            tar_id=i[0],
            tar_name=i[1]
        )
        if not is_target:
            pass
    except:
        pass
