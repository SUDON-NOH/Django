

class purchase_module:

    def pur_category(self):

        self.pur_category = (
            ('Antibody', 'Antibody'),
            ('Antigen', 'Antigen'),
            ('Purification', 'Purification')
        )

        return self.pur_category

