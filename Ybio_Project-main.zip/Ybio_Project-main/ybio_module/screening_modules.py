from Bio import SeqIO
from screening_analysis.models import hl_chain_table
from django.db.models import Count

import os


class ab1_file_control:

    def __init__(self):
        # ab1_file_reader 에서 빈 리스트로 활용
        self.ab1_file_list = []
        # title_without_ext 에서 빈 리스트로 활용
        self.title_list = []
        # split_title 에서 빈 리스트로 활용
        self.split_title_list = []

    """ 
        한 폴더에 있는 ab1 파일들을 수집  
    """
    def ab1_file_reader(self, address):

        dir = address
        file_list = os.listdir(dir)

        for file in file_list:

            # if os.path.splitext(file)[1] == '.ab1':
            if os.path.splitext(file)[1] == '.txt':
                self.ab1_file_list.append(file)
            else:
                pass

        return self.ab1_file_list

    def title_without_ext(self, file_list):

        for file in file_list:

            self.title_list.append(os.path.splitext(file)[0])

        return self.title_list

    """
        파일명을 MID로만 가져가면 없어도 되는 과정임
        filename 명을 불러와서 밑줄(_)을 윗줄(-)로 바꾸고,
        그 바뀐 이름을 split 해서 나눔
        DB에 집어넣기 위한 방법
    """
    def split_title(self, filename):

        no_ext_filename = os.path.splitext(filename)[0]
        replace_title = no_ext_filename.replace("_", "-")
        self.split_title_file = replace_title.split("-")

        return self.split_title_file

    """
        해당 주소에 있는 ab1 파일을 읽어서 seq로 추출함
        이 부분은 screening_abi_database 의 seq로 활용됨
    """
    def ab1_seq(self, address):

        record = SeqIO.read(address, "fasta")
        self.seq = record.seq
        return self.seq

    def ab1_translate(self, sequence):

        # CCATGG 를 찾고, 그 뒤 2칸을 건너뛴 다음부터 본격적인 protein seq 시작
        divided_sequence = sequence.split('GCCATGGCC')
        if len(divided_sequence) == 1:
            divided_sequence = sequence.split('CCATGG')

        try:

            q_sequence = divided_sequence[1].translate().replace("*", "Q")

            dic_end_point = ['EIL', 'TVL', 'DIK', 'EIK', 'EIN', 'EIR', 'ELK', 'ELR', 'EMK', 'EVK', 'NFK', 'QIK', 'GIK',
                             'NIK', 'SVL', 'DIR', 'DII']

        # stop codon 을 따로 설정한다

            for i in dic_end_point:
                end_point_index = q_sequence.find(i, 240)
                if end_point_index != -1:
                    end_point = i
                    self.translated_sequence = q_sequence[:end_point_index+3]
        except:
            pass

        return self.translated_sequence

    def x_ab1_translate(self, sequence):

        # CCATGG 를 찾고, 그 뒤 2칸을 건너뛴 다음부터 본격적인 protein seq 시작
        divided_sequence = sequence.split('GCCATGGCC')
        if len(divided_sequence) == 1:
            divided_sequence = sequence.split('CCATGG')
        try:
            x_sequence = divided_sequence[1].translate()

            dic_end_point = ['EIL', 'TVL', 'DIK', 'EIK', 'EIN', 'EIR', 'ELK', 'ELR', 'EMK', 'EVK', 'NFK', 'QIK', 'GIK',
                             'NIK', 'SVL', 'DIR', 'DII']

            # stop codon 을 따로 설정한다

            for i in dic_end_point:
                end_point_index = x_sequence.find(i, 240)
                if end_point_index != -1:
                    end_point = i
                    self.translated_sequence = x_sequence[:end_point_index + 3]

        except:
            pass

        return self.translated_sequence

    """
    Heavy chain
    Light chain 을 구하기 위한 함수
    """
    def divide_seq(self, sequence):
        self.HVLV = []
        dic_linker = {
                     'GGSSGVSS':'GLGGLGGGGSGGGGSGGSSGVGS',
                     'GSASAPTL':'GSASAPTLGLGGLGGGGSGGGGSGGSSGVGS',
                     'ASTKGPSVGL':'ASTKGPSVGLGGLGGGGSGGGGSGGSSGVGS',
                     'GLGGLGGG':'GLGGLGGGGSGGGGSGGSSGVSS'
                      }

        for i in dic_linker:

            linker_index = sequence.find(i)

            if linker_index != -1:
                linker = dic_linker[i]
                self.HV = sequence[:linker_index]
                self.LV = sequence[linker_index + len(linker):]
                self.HVLV.append(self.HV)
                self.HVLV.append(self.LV)
                self.HVLV.append(linker)
                break
        return self.HVLV

    def save_HVLV(self, tar_id, HL_code, HL_seq):
        HL, is_HL = hl_chain_table.objects.get_or_create(
            tar_id=tar_id,
            HL_code=HL_code,
            HL_seq=HL_seq
        )

        if not is_HL:
            # 중복이면
            # 해당 code_number를 가져와서 입력
            duplicate_hl = hl_chain_table.objects.get(tar_id=tar_id, HL_code=HL_code, HL_seq=HL_seq)
            hl_true = 'F'
            return duplicate_hl.code_number, hl_true

        else:
            # 중복이 아니면
            # 1 부터 숫자를 세서 숫자를 부여
            # seq 는 서로 다르기 때문에 조건으로 넣으면 계속 1만 return 함
            hl_filter_list = hl_chain_table.objects.filter(tar_id=tar_id, HL_code=HL_code)
            count_hl = hl_filter_list.aggregate(Count('HL_code'))

            if count_hl is None:
                num = str(1)
                count_hl = num.zfill(3)
            else:
                num = str(count_hl['HL_code__count'])
                count_hl = num.zfill(3)

            # 중복이 아닌 경우는 count_hl 을 새로 지정하기 때문에 저장해야 함
            HL.code_number = count_hl
            HL.save()
            hl_true = 'T'

            return count_hl, hl_true