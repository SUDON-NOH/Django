# 표준 라이브러리

# Core Django 라이브러리
from django import forms

# 외부 APP

# 내부 APP
from .models import Purchase_Request
from purchase_admin.models import Supplier_info, Catalog_info


class SearchForm(forms.Form):

    search_word = forms.CharField(label='Search Word')


class Order_CreateForm(forms.ModelForm):

    class Meta:
        model = Purchase_Request
        fields = ['cat_id', 'cat', 'cat_name', 'sup_id', 'sup_name', 'order_quantity',
                  'order_url', 'cat_box', 'cat_ea', 'cat_ea_size', 'category', 'exp_price', 'owner']


class SUP_ID_CreateForm(forms.ModelForm):

    class Meta:
        model = Supplier_info
        fields = ['sup_id', 'sup_name']


class CAT_ID_CreateForm(forms.ModelForm):

    class Meta:
        model = Catalog_info
        fields = ['cat_id', 'cat_name', 'cat', 'sup_id', 'cat_box', 'cat_ea', 'cat_ea_size', 'category']