# 표준 라이브러리

# Core Django 라이브러리
from django.urls import path

# 내부 APP
from purchase_order import views

# 외부 APP

app_name = 'purchase_order'

urlpatterns = [

    # SEARCH URL
    # purchase/search
    path('search/', views.SearchFormView.as_view(), name='order_search'),

    # CREATE URL
    # purchase/order/create/SUPID
    path('create/SUPID/', views.SUP_ID_CreateView.as_view(), name='sup_id_add'),
    # purchase/order/create/SUPID/SUP0000
    path('create/SUPID/<str:sup_id>/', views.CAT_ID_CreateView.as_view(), name='cat_id_add'),
    # purchase/order/request/CAT0000
    path('request/<str:cat_id>/', views.Order_CreateView.as_view(), name='order_add'),

    ]

