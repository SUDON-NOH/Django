# 표준라이브러리
import json

# Core 장고 라이브러리
from django.db.models import Q
from django.http import HttpResponse, HttpResponseRedirect
from django.http.response import JsonResponse
# reverse_lazy() 및 reverse() 함수는 url 패턴명을 인자로 받음.
# url 패턴명을 인식하기 위해서는 urls.py 모듈이 메모리에 로딩되어야 함.
# 지금 작성하는 views.py 모듈이 로딩되고 처리되는 시점에 urls.py 모듈이 로딩되지 않을 수도 있기 때문에 reverse() 대신 reverse_lazy()를 임포트함.
from django.urls import reverse_lazy
from django.contrib.auth.mixins import LoginRequiredMixin
from django.shortcuts import render, get_object_or_404
from django.views.generic import FormView, CreateView

# 외부 APP
from purchase_admin.models import Catalog_info, Supplier_info
from Ybio.views import OwnerOnlyMixin


# 내부 APP
from .models import Purchase_Request
from .forms import SearchForm, Order_CreateForm, SUP_ID_CreateForm, CAT_ID_CreateForm


###############################################################################################  Create your views here.
class SearchFormView(LoginRequiredMixin, FormView):

    form_class = SearchForm
    template_name = 'purchase_order/order.html'

    def form_valid(self, form):
        searchWord = form.cleaned_data['search_word']
        choice = form.data.get('TableID')

        if choice == 'cat_id':
            # iexact 는 대소문자 구분 없이 검색할 수 있도록 함.
            choice_list = Catalog_info.objects.filter(Q(cat_id__icontains=searchWord)|
                                                      Q(cat__icontains=searchWord)|
                                                      Q(category__icontains=searchWord)|
                                                      Q(cat_name__icontains=searchWord)).distinct()

            # head_list 를 만들어서 context 변수로 사용,
            # html에서 for 문으로 해당 내용을 사용
            head = 'cat_id'

        elif choice == 'sup_id':
            choice_list = Supplier_info.objects.filter(Q(sup_id__icontains=searchWord)|
                                                       Q(sup_name__icontains=searchWord)).distinct()

            head = 'sup_id'

        else:
            pass
        
        # search_list = []
        # for i in choice_list:
        #     y = {
        #         "sup_id" : i.sup_id,
        #         "sup_name" : i.sup_name
        #     }
        #     search_list.append(y)
    
        # response = JsonResponse(json.dumps(search_list), safe= False)
        
        context = {}
        context['form'] = form
        context['search_term'] = searchWord
        context['object_list'] = choice_list
        context['head'] = head
        # context['choice_list'] = json.dumps(search_list)

        return render(self.request, self.template_name, context)


# 기본 CreateView
class SUP_ID_CreateView(LoginRequiredMixin, CreateView):

    model = Supplier_info
    success_url = reverse_lazy('purchase_order:order_search')
    form_class = SUP_ID_CreateForm
    template_name = 'purchase_order/create_sup_id.html'

    def form_valid(self, form):
        return super().form_valid(form)


class Order_CreateView(LoginRequiredMixin, CreateView):

    model = Purchase_Request
    # 입력이 성공한 뒤 이동할 곳은 추후에 PURCHASE/BOARD로 이동
    success_url = reverse_lazy('purchase_order:order_search')
    form_class = Order_CreateForm
    template_name = 'purchase_order/add.html'

    def get(self, request, *args, **kwargs):
        # form 을 Order_add_View 의 form 을 불러옴.
        # form 의 CAT_ID 열은 GET으로 받아온 CAT_ID 를 기분으로 입력함.
        CAT_ID = self.kwargs['cat_id']

        CAT_LIST = Catalog_info.objects.get(cat_id=CAT_ID)
        SUP_LIST = Supplier_info.objects.get(sup_id=CAT_LIST.sup_id.upper())

        # initial 속성에 넣으면 기본값으로 설정됨
        form = Order_CreateForm(initial={
           'cat_id': CAT_LIST.cat_id,
           'cat': CAT_LIST.cat,
           'cat_name': CAT_LIST.cat_name,
           'sup_id': SUP_LIST.sup_id,
           'sup_name': SUP_LIST.sup_name,
           'category': CAT_LIST.category,
           'cat_box': CAT_LIST.cat_box,
           'cat_ea': CAT_LIST.cat_ea,
           'cat_ea_size': CAT_LIST.cat_ea_size,
           })

        # { } 부분의 form이 없으면 위에서 지정한 입력 form이 나타나지 않음, CAT_ID 부분이 없으면 url 에서 받는 CAT_ID 가 없어짐
        return render(request, self.template_name, {'form': form,
                                                    'cat_id': CAT_ID,
                                                    })

    def post(self, request, *args, **kwargs):
        # Class 에서 정의된 form 을 받음
        form = self.get_form()
        if form.is_valid():
            # OWNER Field 에 요청한 user id를 입력
            form.instance.owner = self.request.user
            # form 을 model 에 적용
            super(Order_CreateView, self).form_valid(form)
            # 성공 후 class 에 정의된 success_url 로 이동
            return HttpResponseRedirect(self.get_success_url())
        return self.form_invalid(form)


class CAT_ID_CreateView(LoginRequiredMixin, CreateView):

    model = Catalog_info
    success_url = reverse_lazy('purchase_order:order_search')
    form_class = CAT_ID_CreateForm
    template_name = 'purchase_order/create_cat_id.html'

    def get(self, request, *args, **kwargs):
        sup_id = self.kwargs['sup_id']
        form = Order_CreateForm(initial={
            'cat_id': 'CAT'+str(Catalog_info.objects.count()+1).zfill(4),
            'sup_id': sup_id,
                                         })
        return render(request, self.template_name, {'form': form,
                                                    'sup_id': sup_id,
                                                    })

    def post(self, request, *args, **kwargs):
        # Class 에서 정의된 form 을 받음
        form = self.get_form()
        if form.is_valid():
            # OWNER Field 에 요청한 user id를 입력
            form.instance.owner = self.request.user
            # form 을 model 에 적용
            super(CAT_ID_CreateView, self).form_valid(form)
            # 성공 후 class 에 정의된 success_url 로 이동
            return HttpResponseRedirect(self.get_success_url())
        return self.form_invalid(form)
