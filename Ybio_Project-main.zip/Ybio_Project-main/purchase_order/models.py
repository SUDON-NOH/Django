# 표준 라이브러리

# Core Django 라이브러리
from django.db import models
from django.conf import settings

# 외부 APP

# 내부 APP
from ybio_module.purchase_modules import purchase_module


# Create your models here.
class Purchase_Request(models.Model):

    # 1. 자동으로 순번 생성
    sn = models.AutoField(primary_key=True)
    # 2. CAT 또는 CAT NAME으로 CAT ID 검색 후 있으면 입력, 없으면 공란
    cat_id = models.CharField('Catalog ID', max_length=7)
    # 3. Catalog code 입력 / CAT ID 검색 후 있으면 자동입력
    cat = models.CharField('Catalog Code', max_length=100)
    # 4. 제품명 입력 / CAT ID 검색 후 있으면 자동입력
    cat_name = models.CharField('Catalog', max_length=100)
    # 5. CAT ID 가 있으면 자동입력, 없으면 공란
    sup_id = models.CharField('Supplier ID', max_length=7)
    # 6. Supplier 입력 / SUP_NAME 으로 SUP_ID 검색 후 있으면 자동입력, 없으면 공란
    sup_name = models.CharField('Supplier NAME', max_length=50)
    # 7. 주문 수량
    order_quantity = models.SmallIntegerField('수량', default=1)
    # 8. 주문 URL
    order_url = models.URLField(max_length=500)
    # 9. CAT_ID가 있으면 자동입력 / BOX의 수량(한 번 구매)
    cat_box = models.SmallIntegerField('Box 단위', default=1)
    # 10. CAT_ID가 있으면 자동입력 / BOX 안에 있는 제품의 수량
    cat_ea = models.SmallIntegerField('EA 단위', default=1)
    # 11. CAT_ID가 있으면 자동입력 / BOX 안에 있는 제품의 용량
    cat_ea_size = models.CharField('EA 용량', max_length=10)
    # 12. CAT_ID가 있으면 자동입력 / 제품 카테고리 입력 / Category_info 의 CATEGORY_CODE
    categories = purchase_module()
    category = models.CharField('Category', max_length=30, choices=categories.pur_category())
    # 13. 예상가격
    exp_price = models.IntegerField('예상 가격')
    # 14. 요청자
    owner = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, blank=True)
    # 15. 요청날짜
    request_dt = models.DateTimeField('Request Date', auto_now_add=True, blank=True)
    # 16. 허가받은 날짜
    permission = models.DateTimeField('Permission Date', null=True, blank=True)
