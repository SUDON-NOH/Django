# 표준 라이브러리

# Core Django 라이브러리
from django.contrib import admin

# 외부 APP

# 내부 APP
from .models import Purchase_Request


# Register your models here.
@admin.register(Purchase_Request)
class Purchase_RequestAdmin(admin.ModelAdmin):

    list_display = ('sn', 'cat_id', 'cat', 'cat_name', 'sup_id', 'sup_name', 'order_quantity', 'cat_box', 'cat_ea',
                    'cat_ea_size', 'category', 'exp_price', 'owner', 'request_dt', 'permission')
    list_filter = ('owner',)
    search_fields = ('owner__usename', 'category', 'cat_id', 'cat', 'owner__username')