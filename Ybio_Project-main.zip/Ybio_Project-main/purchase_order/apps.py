# Core Django 라이브러리
from django.apps import AppConfig


class PurchaseOrderConfig(AppConfig):
    name = 'purchase_order'
