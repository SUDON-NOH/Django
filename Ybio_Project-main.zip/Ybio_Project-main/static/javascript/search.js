'use strict';

const response = response
console.log(response);
