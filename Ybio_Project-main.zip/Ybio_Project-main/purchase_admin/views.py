# 표준 라이브러리

# Core Django 라이브러리
from django.views.generic import ListView, DetailView, UpdateView, DeleteView, CreateView
from django.contrib.auth.mixins import LoginRequiredMixin
from django.urls import reverse_lazy
from django.shortcuts import render
from django.db.models import Q

# 내부 APP
from .models import Vendor_info, Item_info
from purchase_order.models import Purchase_Request
from Ybio.views import OwnerOnlyMixin
from .forms import VEN_ID_CreateForm

# 외부 APP

# Create your views here.


class purchase_Admin_LV(LoginRequiredMixin, ListView):

    model = Purchase_Request
    template_name = 'purchase_admin/list_purchase_request.html'

    def get_queryset(self):
        return Purchase_Request.objects.filter(permission=None)


class VEN_ID_CreateView(LoginRequiredMixin, CreateView):

    model = Vendor_info
    template_name = 'purchase_admin/create_ven_id.html'
    form_class = VEN_ID_CreateForm
    success_url = reverse_lazy('purchase_admin:purchase_admin_LV')

    def form_valid(self, form):
        return super().form_valid(form)


class purchase_Admin_DV(LoginRequiredMixin, ListView):

    model = Item_info
    template_name = 'purchase_admin/list_purchase_request_DV.html'

    def get(self, request, *args, **kwargs):

        self.sn = self.kwargs['sn']
        Purchase_order_info = Purchase_Request.objects.get(sn=self.sn)


        # Item info를 조회해 CAT ID에 해당하는 LIST를 추출
        ITEM_LIST = Item_info.objects.filter(Q(cat_id=Purchase_order_info.cat_id))

        '''
        "shell" 조회방법:
            from purchase_admin.models import Vendor_info, Item_info
            
            item_all = Item_info.objects.select_related('ven_id').all()
            
            for item in item_all: 
                print(item.ven_id.ven_name)
        '''
        context = {}
        context['cat_id'] = Purchase_order_info.cat_id
        context['cat'] = Purchase_order_info.cat
        context['owner'] = Purchase_order_info.owner
        context['request_dt'] = Purchase_order_info.request_dt
        context['cat_name'] = Purchase_order_info.cat_name
        context['category'] = Purchase_order_info.category
        context['sup_id'] = Purchase_order_info.sup_id
        context['sup_name'] = Purchase_order_info.sup_name
        context['order_quantity'] = Purchase_order_info.order_quantity
        context['cat_box'] = Purchase_order_info.cat_box
        context['cat_ea'] = Purchase_order_info.cat_ea
        context['cat_ea_size'] = Purchase_order_info.cat_ea_size
        context['order_url'] = Purchase_order_info.order_url
        context['object_list'] = ITEM_LIST

        return render(request, self.template_name, context)

    # def get_queryset(self):
    #     return Item_info.objects.filter(CAT_ID=CAT_ID)