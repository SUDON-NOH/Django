# 표준 라이브러리

# Core Django 라이브러리
from django.db import models

# 외부 APP
from ybio_module.purchase_modules import purchase_module


# 내부 APP

# ============================================================================================Create your models here.


class Supplier_info(models.Model):

    def objects_count_func():
        objects_count = Supplier_info.objects.count()
        if objects_count is None:
            num = str(1)
            code = 'SUP' + num.zfill(4)
            return code

        else:
            num = str(objects_count + 1)
            code = 'SUP' + num.zfill(4)
            return code

    # SUP0001(자동으로 1씩 증가), Primary Key로 사용
    sup_id = models.CharField('Supplier ID', max_length=7, primary_key=True, default=objects_count_func)
    # 공급처
    sup_name = models.CharField('Supplier NAME', max_length=50, unique=True)

    # def to_json(self):
    #     return {
    #         "sup_id" : self.sup_id,
    #         "sup_name" : self.sup_name
    #     }
    
    class Meta:
        verbose_name = 'Supplier info'
        verbose_name_plural = 'Supplier info'


class Vendor_info(models.Model):

    def objects_count_func():
        objects_count = Vendor_info.objects.count()
        if objects_count is None:
            num = str(1)
            code = 'VEN' + num.zfill(4)
            return code

        else:
            num = str(objects_count + 1)
            code = 'VEN' + num.zfill(4)
            return code

    # VEN0001(자동으로 1씩 증가), Primary Key로 사용
    ven_id = models.CharField('Vendor ID', max_length=7, primary_key=True, default=objects_count_func)
    # 판매처
    ven_name = models.CharField('Vendor Name', max_length=50, unique=True, help_text='업체명을 정확히 입력하세요.')
    # 업체 전화번호
    ven_tel = models.CharField('Vendor Tel num', max_length=20, unique=True)
    # 업체 FAX번호
    ven_fax = models.CharField('Vendor Fax num', max_length=20, blank=True)
    # 업체 Email
    ven_email = models.EmailField('Vendor Email', blank=True)

    class Meta:
        verbose_name = 'Vendor info'
        verbose_name_plural = 'Vendor info'


class Catalog_info(models.Model):

    def objects_count_func():
        objects_count = Catalog_info.objects.count()
        if objects_count is None:
            num = str(1)
            code = 'CAT' + num.zfill(4)
            return code

        else:
            num = str(objects_count + 1)
            code = 'CAT' + num.zfill(4)
            return code

    # CAT0001(자동으로 1씩 증가), Primary Key로 사용
    cat_id = models.CharField('CAT ID', max_length=7, primary_key=True, default=objects_count_func)
    # 제품명
    cat_name = models.CharField('Catalog', max_length=200, unique=True)
    # 업체의 Catalog code
    cat = models.CharField('Catalog Code', max_length=100, unique=True)
    # Supplier_info 의 SUP_ID
    sup_id = models.CharField('Supplier ID', max_length=7)
    # BOX의 수량(한 번 구매)
    cat_box = models.SmallIntegerField('Box 단위', default=1)
    # BOX 안에 있는 제품의 수량
    cat_ea = models.SmallIntegerField('EA 단위', default=1)
    # BOX 안에 있는 제품의 용량
    cat_ea_size = models.CharField('EA 용량', max_length=10)
    # Category_info 의 CATEGORY_CODE
    categories = purchase_module()
    category = models.CharField('Category', max_length=30, choices=categories.pur_category())

    class Meta:
        verbose_name = 'Catalog info'
        verbose_name_plural = 'Catalog info'


class Item_info(models.Model):

    def objects_count_func():
        objects_count = Item_info.objects.count()
        if objects_count is None:
            num = str(1)
            code = 'IT' + num.zfill(4)
            return code

        else:
            num = str(objects_count + 1)
            code = 'IT' + num.zfill(4)
            return code

    it_id = models.CharField('Item ID', max_length=6, primary_key=True, default=objects_count_func)
    # ForeignKey ForeignKey('대상이 되는 테이블(class)', '삭제 시 이슈', '
    ven_id = models.ForeignKey('Vendor_info', related_name='vendor_id', on_delete=models.PROTECT, db_column='ven_id')
    sup_id = models.ForeignKey('Supplier_info', related_name='supplier_id',
                               on_delete=models.PROTECT, db_column='sup_id')
    cat_id = models.ForeignKey('Catalog_info', related_name='catalog_id', on_delete=models.PROTECT, db_column='cat_id')
    price = models.IntegerField('가격')

    class Meta:
        verbose_name = 'Item info'
        verbose_name_plural = 'Item info'


class PSN_info(models.Model):

    def objects_count_func():
        objects_count = PSN_info.objects.count()
        if objects_count is None:
            num = str(1)
            code = 'PSN' + num.zfill(5)
            return code

        else:
            num = str(objects_count + 1)
            code = 'PSN' + num.zfill(5)
            return code

    psn_id = models.CharField('PSN ID',  max_length=8, primary_key=True, default=objects_count_func)
    it_id = models.CharField('Item ID', max_length=6)
    permission_dt = models.DateField('Permission Date', auto_now_add=True)
    requester = models.CharField('연구원', max_length=10)
    ven_order_url = models.URLField(max_length=500)
    order_quantity = models.SmallIntegerField('수량', default=1)
    price = models.IntegerField('가격')
    amount = models.IntegerField('합계', blank=True)
    cost_category = models.CharField('비용구분', max_length=50)
    purchase_number = models.CharField('구매번호', max_length=100, blank=True)
    issue_dt = models.DateField('발행일', null=True, blank=True)
    deposit_dt = models.DateField('입금일', null=True, blank=True)
    eta = models.DateField('입고 예정일', null=True, blank=True)
    arrival_dt = models.DateField('입고일', null=True, blank=True)
    memo = models.TextField('비고', max_length=300, blank=True)

    class Meta:
        # 관리자 화면에 표시되는 이름
        verbose_name = 'Psn_info'
        # 관리자 화면에 표시되는 이름의 복수형 한국에서는 verbose_name 과 똑같이 해서 사용
        # plural 을 지정하지 않으면 verbose_name 끝에 s가 붙음
        verbose_name_plural = 'Psn_info'

    def save(self, *args, **kwargs):
        self.amount = self.order_quantity * self.price
        super(PSN_info, self).save(*args, **kwargs)

#
# class Category_info(models.Model):
#
#     CATEGORY_CODE = models.CharField(max_length=2, primary_key=True)
#     CATEGORY_VALUE = models.CharField(max_length=50, unique=True)



