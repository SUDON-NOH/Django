# 표준 라이브러리

# Core Django 라이브러리
from django.urls import path

# 내부 APP
from purchase_admin import views

# 외부 APP

# --------------------------------------------------------------------

app_name = 'purchase_admin'

urlpatterns = [
    # purchase/admin/List/
    path('List/', views.purchase_Admin_LV.as_view(), name='purchase_admin_LV'),
    # purchase/admin/List/
    path('List/<int:sn>/', views.purchase_Admin_DV.as_view(), name='purchase_admin_DV'),

    path('Create/venid/', views.VEN_ID_CreateView.as_view(), name='ven_id_add'),
]