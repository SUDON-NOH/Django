from django.apps import AppConfig


class PurchaseAdminConfig(AppConfig):
    name = 'purchase_admin'
