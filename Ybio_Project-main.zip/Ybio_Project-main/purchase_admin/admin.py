from django.contrib import admin
from .models import Supplier_info, Vendor_info, Catalog_info, Item_info, PSN_info


# Register your models here.
@admin.register(Supplier_info)
class Supplier_infoAdmin(admin.ModelAdmin):
    list_display = ('sup_id', 'sup_name')
    list_filter = ('sup_id',)
    search_fields = ('sup_name', 'sup_id')


@admin.register(Vendor_info)
class Vendor_infoAdmin(admin.ModelAdmin):
    list_display = ('ven_id', 'ven_name', 'ven_tel', 'ven_fax', 'ven_email')
    list_filter = ('ven_id',)
    search_fields = ('ven_name', 'ven_id')


@admin.register(Catalog_info)
class Catalog_infoAdmin(admin.ModelAdmin):
    list_display = ('cat_id', 'cat_name', 'sup_id', 'category')
    list_filter = ('cat_id',)
    search_fields = ('cat_name', 'cat_id', 'sup_id__sup_id', 'sup_id__sup_name')


@admin.register(Item_info)
class Item_infoAdmin(admin.ModelAdmin):
    list_display = ('it_id', 'ven_id', 'sup_id', 'cat_id')
    list_fields = ('it_id',)
    search_fields = ('it_id', 'cat_id__cat_id', 'cat_name__cat_name', 'ven_id__ven_id', 'ven_id__ven_name',
                     'sup_id__sup_id', 'sup_id__sup_name')


@admin.register(PSN_info)
class PSN_infoAdmin(admin.ModelAdmin):
    list_display = ('psn_id', 'it_id', 'permission_dt', 'requester', 'order_quantity', 'price', 'amount',
                    'cost_category', 'purchase_number', 'issue_dt', 'deposit_dt', 'eta', 'arrival_dt', 'memo')
    list_filter = ('psn_id',)
    search_fields = ('psn_name', 'it_id', 'requester', 'cost_category', 'purchase_number')


