# 표준 라이브러리

# Core Django 라이브러리
from django import forms

# 외부 APP

# 내부 APP
from .models import Vendor_info, PSN_info
from purchase_order.models import Purchase_Request


# VENDOR ID 생성 Form
class VEN_ID_CreateForm(forms.ModelForm):

    class Meta:
        model = Vendor_info
        fields = ['ven_id', 'ven_name', 'ven_tel', 'ven_fax', 'ven_email']


class PSN_CreateForm(forms.ModelForm):

    class Meta:
        model = PSN_info
        fields = ['psn_id', 'it_id', 'requester', 'ven_order_url', 'order_quantity', 'price',
                  'amount', 'cost_category', 'purchase_number', 'issue_dt', 'deposit_dt', 'eta', 'arrival_dt', 'memo']