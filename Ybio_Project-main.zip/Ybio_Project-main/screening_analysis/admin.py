from django.contrib import admin
from .models import target_table, screening_ab1_database, hl_chain_table, screening_SA, screening_AG


@admin.register(target_table)
class target_tableAdmin(admin.ModelAdmin):

    list_display = ('tar_id', 'tar_name')
    list_filter = ('tar_id',)
    search_fields = ['tar_id', 'tar_name']


@admin.register(hl_chain_table)
class hl_chain_tableAdmin(admin.ModelAdmin):

    list_display = ('tar_id', 'HL_code', 'code_number', 'HL_seq')
    list_filter = ('tar_id', )
    search_fields = ['tar_id__tar_id', 'HL_code', 'code_number', 'tar_id__tar_name', 'user__username']
    raw_id_fields = (
        'tar_id',
    )


@admin.register(screening_ab1_database)
class screening_ab1_databaseAdmin(admin.ModelAdmin):

    list_display = ('id', 'mid', 'status', 'VH_code', 'VL_code', 'date', 'paid', 'tar_id', 'clone_name',
                    'primer', 'direction', 'group')
    list_filter = ('mid',)
    # search field 에서 icontains error 발생시
    search_fields = ['mid', 'date', 'paid', 'clone_name', 'group', 'status',
                     'tar_id__tar_id', 'tar_id__tar_name', 'user__username']
    raw_id_fields = (
        'tar_id',
    )


@admin.register(screening_SA)
class screening_SAAdmin(admin.ModelAdmin):

    list_display = ('sid', 'tar_id', 'tar_name', 'sa_name', 'isoheavy', 'isolight', 'modi', 'moc')
    list_filter = ('sid', )
    search_fields = ['sid', 'tar_id', 'tar_name', 'sa_name', 'isoheavy', 'isolight', ]


@admin.register(screening_AG)
class screening_AGAdmin(admin.ModelAdmin):

    list_display = ('agid', 'date', 'constructor', 'user', 'ag_name', 'gene', 'fid', 'vector', 'genevar', 'ld', 'structure', 'string')
    list_filter = ('agid',)
    search_fields = ['agid', 'date', 'constructor', 'user', 'ag_name', 'gene', 'fid', 'vector']