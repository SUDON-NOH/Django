from django.db import models
from django.core.files.storage import FileSystemStorage
import os
from django.conf import settings


class OverwriteStorage(FileSystemStorage):
    def get_available_name(self, name, max_length=None):
        if self.exists(name):
            os.remove(os.path.join(settings.MEDIA_ROOT, name))
        return name


class target_table(models.Model):
    tar_id = models.CharField('Target ID', max_length=7, primary_key=True)
    tar_name = models.CharField('Target Name', max_length=10, unique=True)


class hl_chain_table(models.Model):
    tar_id = models.ForeignKey('target_table', related_name='HL_table_tar', on_delete=models.PROTECT, db_column='tar_id')
    HL_code = models.CharField('H/L code', max_length=10, choices=(("H", "H"), ("L", "L")))
    code_number = models.CharField('code_number', max_length=10)
    HL_seq = models.CharField('H/L seq', max_length=1000)


class screening_ab1_database(models.Model):
    mid = models.CharField('M ID', max_length=7)
    date = models.CharField('DATE', max_length=8)
    paid = models.CharField('PA ID', max_length=7)
    tar_id = models.ForeignKey('target_table', related_name='screening_ab1_db_tar', on_delete=models.PROTECT, db_column='tar_id')
    clone_name = models.CharField('Clone name', max_length=8)
    primer = models.CharField('Primer name', max_length=15)
    direction = models.CharField('direction', max_length=4)
    seq = models.CharField('Sequence', max_length=3000)
    ab1_file = models.FileField(upload_to='media/screening_ab1', storage=OverwriteStorage(), null=True)
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, blank=True, related_name='screening_ab1_db_user', db_column='user_id')
    status = models.CharField('Status', max_length=30, choices=(
        ('CONFIRM', 'CONFIRM'),
        ('NEW', 'NEW'),
        ('PASS', 'PASS'),
        ('FAIL', 'FAIL'),
        ('NOISE', 'NOISE'),
        ('FINISH', 'FINISH')), default='HOLD')
    group = models.IntegerField('Group', null=True)
    protein_seq = models.CharField('Protein Sequence', max_length=3000, null=True, blank=True)
    protein_seq_x = models.CharField('Protein Sequence include "X"', max_length=3000, null=True, blank=True)
    VH_code = models.CharField('Heavy Chain', max_length=10, null=True, blank=True)
    VL_code = models.CharField('Light Chain', max_length=10, null=True, blank=True)
    memo = models.CharField('memo', max_length=300, null=True, blank=True)

    # 임시로 활용하는 column
    @property
    def count_x(self):
        return self.protein_seq_x.count('*')


class screening_SA(models.Model):
    sid = models.CharField('S ID', max_length=15, null=True, blank=True)
    tar_id = models.CharField('Target ID', max_length=20, null=True, blank=True)
    tar_name = models.CharField('Target name', max_length=30, null=True, blank=True)
    sa_name = models.CharField('NAME', max_length=30, null=True, blank=True)
    isoheavy = models.CharField('ISOHEAVEY', max_length=30, null=True, blank=True)
    isolight = models.CharField('ISOLIGHT', max_length=30, null=True, blank=True)
    vh = models.CharField('VH', max_length=3000, null=True, blank=True)
    vl = models.CharField('VL', max_length=3000, null=True, blank=True)
    ch = models.CharField('CH', max_length=3000, null=True, blank=True)
    cl = models.CharField('CL', max_length=3000, null=True, blank=True)
    heavey = models.CharField('HEAVY', max_length=3000, null=True, blank=True)
    light = models.CharField('LIGHT', max_length=3000, null=True, blank=True)
    modi = models.CharField('MODI', max_length=30, null=True, blank=True)
    moc = models.CharField('MOC', max_length=30, null=True, blank=True)


class screening_AG(models.Model):
    agid = models.CharField('ID', max_length=15, null=True, blank=True)
    date = models.DateTimeField('Date', null=True, blank=True)
    constructor = models.CharField('CONSTRUCTOR', max_length=10, null=True, blank=True)
    user = models.CharField('USER', max_length=10, null=True, blank=True)
    ag_name = models.CharField('NAME', max_length=100, null=True, blank=True)
    gene = models.CharField('GENE', max_length=20, null=True, blank=True)
    fid = models.CharField('FID', max_length=20, null=True, blank=True)
    vector = models.CharField('VECTOR', max_length=10, null=True, blank=True)
    genevar = models.CharField('GENEVAR', max_length=10, null=True, blank=True)
    ld = models.CharField('LD', max_length=10, null=True, blank=True)
    dna = models.CharField('DNA', max_length=1000, null=True, blank=True)
    protein = models.CharField('PROTEIN', max_length=1000, null=True, blank=True)
    wclone = models.CharField('WCLONE', max_length=1000, null=True, blank=True)
    structure = models.CharField('STRUCTURE', max_length=200, null=True, blank=True)
    F = models.IntegerField('F', null=True, blank=True)
    L = models.IntegerField('L', null=True, blank=True)
    term = models.CharField('TERM', max_length=30, null=True, blank=True)
    string = models.CharField('STRING', max_length=1000, null=True, blank=True)

