# 표준 라이브러리

# Core Django 라이브러리
from django.urls import path
from django.conf import settings
from django.conf.urls.static import static

# 내부 APP
from screening_analysis import views

# 외부 APP

app_name = 'screening_analysis'


urlpatterns = [

    # analysis
    # ab1 file upload page
    path('ab1/reader/', views.screening_ab1_save_view.as_view(), name="ab1_reader"),
    # ab1 file batch
    path('ab1/reader/batch/list/', views.screening_batch_view.as_view(), name="ab1_batch_list"),
    # batch check noise
    path('ab1/reader/batch/<int:group>/', views.screening_noise_check_view.as_view(), name="batch_check_noise"),
    # passed batch list by group
    path('ab1/reader/pass/batch/list/', views.screening_pass_batch_view.as_view(), name="batch_pass"),
    # passed batch list in group
    path('ab1/reader/pass/batch/list/<int:group>/', views.screening_pass_batch_list_view.as_view(), name="batch_pass_list"),
    # update passed mid
    path('ab1/reader/pass/batch/list/update/<int:pk>/', views.screening_pass_mid_update.as_view(), name="mid_pass_update"),
    # detail passed mid
    path('ab1/reader/pass/batch/list/detail/<int:pk>/', views.screening_pass_mid_detail.as_view(),
         name="mid_pass_detail"),
    # noise batch list by group
    path('ab1/reader/noise/batch/list/', views.screening_noise_batch_view.as_view(), name="batch_noise"),
    # noise batch list in group
    path('ab1/reader/noise/batch/list/<int:group>/', views.screening_noise_batch_list_view.as_view(),
         name="batch_noise_list"),
    # update noise mid
    path('ab1/reader/noise/batch/list/update/<int:pk>/', views.screening_noise_mid_update.as_view(),
         name="mid_noise_update"),
    # detail noise mid
    path('ab1/reader/noise/batch/list/detail/<int:pk>/', views.screening_noise_mid_detail.as_view(),
         name="mid_noise_detail"),
    # finish batch list by group
    path('ab1/reader/finish/batch/list/', views.screening_finish_batch_view.as_view(), name="batch_finish"),
    # finish batch list in group
    path('ab1/reader/finish/batch/list/<int:group>/', views.screening_finish_batch_list_view.as_view(),
         name="batch_finish_list"),
    # detail finish mid
    path('ab1/reader/finish/batch/list/detail/<int:pk>/', views.screening_finish_mid_detail.as_view(),
         name="mid_finish_detail"),
    # screening search
    path('ab1/search/', views.screening_search_view.as_view(), name='screening_search'),

]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
