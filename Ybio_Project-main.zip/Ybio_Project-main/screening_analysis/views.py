# 표준라이브러리
import time
from datetime import datetime

# Core 장고 라이브러리
from django.core.files.storage import FileSystemStorage
from django.db.models import Max, Count, Q
from django.shortcuts import render
from django.views.generic import FormView, ListView, UpdateView, DetailView
from django.urls import reverse_lazy
from django.contrib.auth.mixins import LoginRequiredMixin
from django.http import HttpResponse, HttpResponseRedirect

# 내부 APP
from .forms import screening_ab1_Form, screening_searchForm
from .models import screening_ab1_database, target_table, hl_chain_table, screening_SA, screening_AG

# 외부 APP
from ybio_module.screening_modules import ab1_file_control
from account.models import customUser


# ab1 file 을 입력하는 view
class screening_ab1_save_view(LoginRequiredMixin, FormView):

    form_class = screening_ab1_Form
    template_name = 'screening_analysis/analysis_ab1_reader.html'
    success_url = reverse_lazy('screening_analysis:ab1_reader')

    def post(self, request, *args, **kwargs):

        form_class = self.get_form_class()
        form = self.get_form(form_class)
        files = request.FILES.getlist('file_field')

        if form.is_valid():

            self.saved_list = []
            self.except_list = []
            fs = FileSystemStorage(location='media/screening_ab1', base_url='media/screening_ab1')
            control = ab1_file_control()
            USER = customUser.objects.get(username=self.request.user)

            # 입력하는 user를 필터링해 그 인원이 입력한 값들 중 group 값의 최대값을 찾음
            user_filter_list = screening_ab1_database.objects.filter(user=USER)
            group_max = user_filter_list.aggregate(Max('group'))['group__max']
            # 사용자가 최초 입력하는 사용자면 group_max 는 0으로 수동으로 설정함
            if group_max is None:
                group_max = 0

            for f in files:
                # time.sleep(2)
                split_name = control.split_title(f.name)

                try:
                    filename = fs.save(f.name, f)
                    # sequence 변환
                    seq = control.ab1_seq(fs.url(f.name))
                    print("2:  ", filename)
                    # x 값이 포함된 seq
                    try:
                        protein_seq_x = control.x_ab1_translate(seq)

                    except:
                        protein_seq_x = ""

                    # x 값이 포함되지 않은 seq
                    try:
                       protein_seq = control.ab1_translate(seq)
                    except:
                        fs.delete(filename)
                        ab1_file = ""

                    tar_id = target_table.objects.get(tar_id=split_name[3])

                    try:
                        create_mid, is_mid = screening_ab1_database.objects.get_or_create(
                            mid=split_name[0],
                            date=split_name[1],
                            paid=split_name[2],
                            tar_id=tar_id,
                            clone_name=split_name[4],
                            primer=split_name[5],
                            direction=split_name[6],
                            seq=seq,
                            ab1_file=fs.url(f.name),
                            user=USER,
                            protein_seq=protein_seq,
                            protein_seq_x=protein_seq_x,
                        )

                    except:
                        fs.delete(filename)
                        break

                    if not is_mid:
                        # 중복이면 파일 삭제
                        fs.delete(filename)
                        self.except_list.append(f.name)

                    else:
                        # 중복이 아니면 저장

                        # heavy chain 과 light chain을 받음
                        # 0번 index는 hv / 1번 index는 lv / 2번 index는 linker
                        hl_chain = control.divide_seq(protein_seq.replace('X', 'Q'))

                        # heavy chain 이 hl_chain_table 의 VH 열에 있나 없나 체크
                        vh_number, vh_true = control.save_HVLV(tar_id, "H", hl_chain[0])

                        # light chain 이 hl_chain_table 의 VL 열에 있나 없나 체크
                        vl_number, vl_true = control.save_HVLV(tar_id, "L", hl_chain[1])

                        # mid 가 같고, direction 이 같은 값을 찾아 group 번호를 부여함
                        group_update = screening_ab1_database.objects.get(
                            mid=split_name[0],
                            direction=split_name[6]
                        )

                        group_update.group = group_max + 1
                        group_update.VH_code = vh_number
                        group_update.VL_code = vl_number

                        # 변경이 필요한 부분임. 그 이유는 NOISE 된 것들 포함 VH/VL이 생길 수 있기 때문에
                        # 따라서 이 부분은 마지막 finish 된 것들의 vh / vl 과 비교하고,
                        # vh/vl 조합을 가진게 finish 됐다? 그럼 중복
                        # finish 안됐으면 중복 아닌 것으로 처리
                        if vh_true == 'T' or vl_true == 'T':
                            group_update.status = 'NEW'
                        else:
                            group_update.status = 'PASS'
                            # 중복된 값 표시 변경
                            # tar_id 가 같은 것들 중에, status가 finish 거나 new 이고, 전체 시퀀스(X를 Q로 변경한)가 동일한 값이
                            # 있으면 중복처리 아니면 신규 NEW 처리
                            q = Q()
                            q.add(Q(tar_id=tar_id), q.AND)
                            q.add(Q(status='FINISH')|Q(status='NEW'), q.AND)
                            q.add(Q(protein_seq=protein_seq), q.AND)

                            duplicate_list = screening_ab1_database.objects.filter(q)

                            if len(duplicate_list) == 0:
                                group_update.status = 'NEW'
                            else:
                                group_update.status = 'PASS'

                        group_update.save()

                        # 출력을 위해 USER ID 를 "split_name"에 추가
                        split_name.append(self.request.user)
                        self.saved_list.append(split_name)
                except:
                    mid_update = screening_ab1_database.objects.get(
                        mid=split_name[0],
                        direction=split_name[6]
                    )
                    mid_update.status = 'FAIL'
                    mid_update.group = group_max + 1
                    mid_update.save()
                    self.except_list.append(f.name)
                    pass

            return render(request, 'screening_analysis/analysis_ab1_reader.html', {
                'saved_list': self.saved_list,
                'except_list': self.except_list,
            })

        else:
            return self.form_invalid(form)


# 저장된 batch 를 보여주는 view
class screening_batch_view(LoginRequiredMixin, ListView):

    model = screening_ab1_database
    template_name = 'screening_analysis/analysis_batch_view.html'

    def get(self, request, *args, **kwargs):
        user = self.request.user
        object_list = screening_ab1_database.objects.filter(
            user=user,
            status='NEW'
        ).values(
            'group',
            'date',
            'tar_id',
            'user',
            'status',
        ).annotate(Count=Count('group'))

        return render(request, self.template_name, {
            'object_list': object_list,
        })


# noise 를 check 하는 view
class screening_noise_check_view(LoginRequiredMixin, FormView):

    # form_class = screening_noise_check_Form
    template_name = "screening_analysis/analysis_batch_check_noise.html"
    success_url = reverse_lazy('screening_analysis:batch_pass')

    def get(self, request, *args, **kwargs):

        self.batch_group = self.kwargs['group']
        object_list = screening_ab1_database.objects.filter(
            group=self.batch_group,
            status="NEW"
        )
        return render(request, self.template_name, {
            'object_list': object_list,
            'group': self.batch_group
        })

    def post(self, request, *args, **kwargs):
        noise_list = request.POST.getlist('noise_list')
        pass_list = request.POST.getlist('pass_list')

        for i in pass_list:
            a = i.split(',')
            p = a[0].strip()
            q = a[1].strip()
            update_row = screening_ab1_database.objects.get(
                mid=p,
                direction=q
            )
            update_row.status = "CONFIRM"
            update_row.save()

        for i in noise_list:
            a = i.split(',')
            p = a[0].strip()
            q = a[1].strip()
            update_row = screening_ab1_database.objects.get(
                mid=p,
                direction=q
            )
            update_row.status = "NOISE"
            update_row.save()

        return HttpResponseRedirect(self.get_success_url())


# pass 된 batch 를 보여주는 view
class screening_pass_batch_view(LoginRequiredMixin, ListView):

    model = screening_ab1_database
    template_name = 'screening_analysis/analysis_pass_batch_view.html'

    def get(self, request, *args, **kwargs):
        user = self.request.user
        object_list = screening_ab1_database.objects.filter(
            user=user,
            status='CONFIRM'
        ).values(
            'group',
            'date',
            'tar_id',
            'user',
            'status',
        ).annotate(Count=Count('group'))

        return render(request, self.template_name, {
            'object_list': object_list,
        })


# noise 된 batch 를 보여주는 view
class screening_noise_batch_view(LoginRequiredMixin, ListView):

    model = screening_ab1_database
    template_name = 'screening_analysis/analysis_noise_batch_view.html'

    def get(self, request, *args, **kwargs):
        user = self.request.user
        object_list = screening_ab1_database.objects.filter(
            user=user,
            status='NOISE'
        ).values(
            'group',
            'date',
            'tar_id',
            'user',
            'status',
        ).annotate(Count=Count('group'))

        return render(request, self.template_name, {
            'object_list': object_list,
        })


# pass 된 batch 의 리스트를 보여주는 view
class screening_pass_batch_list_view(LoginRequiredMixin, FormView):

    template_name = "screening_analysis/analysis_pass_list_view.html"
    success_url = reverse_lazy("screening_analysis:batch_pass")

    def get(self, request, *args, **kwargs):
        self.pass_batch_group = self.kwargs['group']
        object_list = screening_ab1_database.objects.filter(
            group=self.pass_batch_group,
            status="CONFIRM"
        )

        return render(request, self.template_name, {
            'object_list': object_list,
            'group': self.pass_batch_group,
        })

    def post(self, request, *args, **kwargs):
        # object_list = request.POST.getlist['form_A']
        post_group = request.POST.get('group')
        object_list = screening_ab1_database.objects.filter(
            group=post_group,
            status='CONFIRM',
        )
        for object in object_list:
            if object.protein_seq == object.protein_seq_x:
                object.status = 'FINISH'
                object.save()
            else:
                pass

        return HttpResponseRedirect(self.get_success_url())


# pass 된 batch 의 update view 를 보여주는 view
class screening_pass_mid_update(LoginRequiredMixin, FormView):

    template_name = "screening_analysis/screening_pass_mid_update_form.html"
    # success_url = reverse_lazy('screening_analysis:batch_pass_list')

    def get(self, request, *args, **kwargs):
        pk_id = self.kwargs['pk']
        object_one = screening_ab1_database.objects.get(pk=pk_id)
        object_date = datetime.strptime(object_one.date, "%Y%m%d")
        object_x_seq = list(object_one.protein_seq_x)
        object_x_seq = {i: j for i, j in enumerate(object_x_seq)}

        return render(request, self.template_name, {
            'mid': object_one.mid,
            'date': object_date,
            'paid': object_one.paid,
            'tar_id': object_one.tar_id.tar_id,
            'tar_name': object_one.tar_id.tar_name,
            'clone_name': object_one.clone_name,
            'primer': object_one.primer,
            'direction': object_one.direction,
            'VH_code': object_one.VH_code,
            'VL_code': object_one.VL_code,
            'count_x': object_one.count_x,
            'protein_seq_x': object_x_seq,
            'group': object_one.group,
        })

    def post(self, request, *args, **kwargs):
        changed_seq = request.POST.getlist("seq")
        self.group = request.POST.get('group')
        mid = request.POST.get('mid')
        direction = request.POST.get('direction')
        changed_seq = ''.join(changed_seq)

        update_row = screening_ab1_database.objects.get(
            mid=mid,
            direction=direction,
        )
        update_row.protein_seq = changed_seq
        update_row.protein_seq_x = changed_seq
        update_row.save()

        return HttpResponseRedirect(self.get_success_url())

    def get_success_url(self):
        return reverse_lazy('screening_analysis:batch_pass_list', kwargs={'group': self.group})


# pass 된 batch 의 detail view 를 보여주는 view
class screening_pass_mid_detail(LoginRequiredMixin, FormView):

    template_name = "screening_analysis/screening_pass_mid_detail_form.html"
    # success_url = reverse_lazy('screening_analysis:batch_pass_list')

    def get(self, request, *args, **kwargs):
        pk_id = self.kwargs['pk']
        object_one = screening_ab1_database.objects.get(pk=pk_id)
        object_date = datetime.strptime(object_one.date, "%Y%m%d")
        object_x_seq = list(object_one.protein_seq_x)
        object_x_seq = {i: j for i, j in enumerate(object_x_seq)}

        return render(request, self.template_name, {
            'mid': object_one.mid,
            'date': object_date,
            'paid': object_one.paid,
            'tar_id': object_one.tar_id.tar_id,
            'tar_name': object_one.tar_id.tar_name,
            'clone_name': object_one.clone_name,
            'primer': object_one.primer,
            'direction': object_one.direction,
            'VH_code': object_one.VH_code,
            'VL_code': object_one.VL_code,
            'count_x': object_one.count_x,
            'protein_seq_x': object_x_seq,
            'group': object_one.group,
        })


# noise 된 batch 의 리스트를 보여주는 view
class screening_noise_batch_list_view(LoginRequiredMixin, FormView):

    template_name = "screening_analysis/analysis_noise_list_view.html"
    success_url = reverse_lazy("screening_analysis:batch_noise")

    def get(self, request, *args, **kwargs):
        self.noise_batch_group = self.kwargs['group']
        object_list = screening_ab1_database.objects.filter(
            group=self.noise_batch_group,
            status="NOISE"
        )

        return render(request, self.template_name, {
            'object_list': object_list,
            'group': self.noise_batch_group,
        })

    def post(self, request, *args, **kwargs):
        post_group = request.POST.get('group')
        object_list = screening_ab1_database.objects.filter(
            group=post_group,
            status='NOISE',
        )
        for object in object_list:
            if object.protein_seq == object.protein_seq_x:
                object.status = 'CONFIRM'
                object.save()
            else:
                pass

        return HttpResponseRedirect(self.get_success_url())


# noise 된 batch 의 update view 를 보여주는 view
class screening_noise_mid_update(LoginRequiredMixin, FormView):

    template_name = "screening_analysis/screening_noise_mid_update_form.html"
    # success_url = reverse_lazy('screening_analysis:batch_pass_list')

    def get(self, request, *args, **kwargs):
        pk_id = self.kwargs['pk']
        object_one = screening_ab1_database.objects.get(pk=pk_id)
        object_date = datetime.strptime(object_one.date, "%Y%m%d")
        object_x_seq = list(object_one.protein_seq_x)
        object_x_seq = {i: j for i, j in enumerate(object_x_seq)}

        return render(request, self.template_name, {
            'mid': object_one.mid,
            'date': object_date,
            'paid': object_one.paid,
            'tar_id': object_one.tar_id.tar_id,
            'tar_name': object_one.tar_id.tar_name,
            'clone_name': object_one.clone_name,
            'primer': object_one.primer,
            'direction': object_one.direction,
            'VH_code': object_one.VH_code,
            'VL_code': object_one.VL_code,
            'count_x': object_one.count_x,
            'protein_seq_x': object_x_seq,
            'group': object_one.group,
        })

    def post(self, request, *args, **kwargs):
        changed_seq = request.POST.getlist("seq")
        self.group = request.POST.get('group')
        mid = request.POST.get('mid')
        direction = request.POST.get('direction')
        changed_seq = ''.join(changed_seq)

        update_row = screening_ab1_database.objects.get(
            mid=mid,
            direction=direction,
        )
        update_row.protein_seq = changed_seq
        update_row.protein_seq_x = changed_seq
        update_row.save()

        return HttpResponseRedirect(self.get_success_url())

    def get_success_url(self):
        return reverse_lazy('screening_analysis:batch_noise_list', kwargs={'group': self.group})


# noise 된 batch 의 detail view 를 보여주는 view
class screening_noise_mid_detail(LoginRequiredMixin, FormView):

    template_name = "screening_analysis/screening_noise_mid_detail_form.html"

    def get(self, request, *args, **kwargs):
        pk_id = self.kwargs['pk']
        object_one = screening_ab1_database.objects.get(pk=pk_id)
        object_date = datetime.strptime(object_one.date, "%Y%m%d")
        print(object_one.protein_seq_x)
        object_x_seq = list(object_one.protein_seq_x)
        object_x_seq = {i: j for i, j in enumerate(object_x_seq)}

        return render(request, self.template_name, {
            'mid': object_one.mid,
            'date': object_date,
            'paid': object_one.paid,
            'tar_id': object_one.tar_id.tar_id,
            'tar_name': object_one.tar_id.tar_name,
            'clone_name': object_one.clone_name,
            'primer': object_one.primer,
            'direction': object_one.direction,
            'VH_code': object_one.VH_code,
            'VL_code': object_one.VL_code,
            'count_x': object_one.count_x,
            'protein_seq_x': object_x_seq,
            'group': object_one.group,
        })


# finish 된 batch 를 보여주는 view
class screening_finish_batch_view(LoginRequiredMixin, ListView):

    model = screening_ab1_database
    template_name = 'screening_analysis/analysis_finish_batch_view.html'

    def get(self, request, *args, **kwargs):
        user = self.request.user
        object_list = screening_ab1_database.objects.filter(
            user=user,
            status='FINISH'
        ).values(
            'group',
            'date',
            'tar_id',
            'user',
            'status',
        ).annotate(Count=Count('group'))

        return render(request, self.template_name, {
            'object_list': object_list,
        })


# finish 된 batch 의 리스트를 보여주는 view
class screening_finish_batch_list_view(LoginRequiredMixin, FormView):

    template_name = "screening_analysis/analysis_finish_list_view.html"

    def get(self, request, *args, **kwargs):
        self.finish_batch_group = self.kwargs['group']
        object_list = screening_ab1_database.objects.filter(
            group=self.finish_batch_group,
            status="FINISH"
        )

        return render(request, self.template_name, {
            'object_list': object_list,
            'group': self.finish_batch_group,
        })


# finish 된 batch 의 detail view 를 보여주는 view
class screening_finish_mid_detail(LoginRequiredMixin, FormView):

    template_name = "screening_analysis/screening_finish_mid_detail_form.html"

    def get(self, request, *args, **kwargs):
        pk_id = self.kwargs['pk']
        object_one = screening_ab1_database.objects.get(pk=pk_id)
        object_date = datetime.strptime(object_one.date, "%Y%m%d")
        print(object_one.protein_seq_x)
        object_x_seq = list(object_one.protein_seq_x)
        object_x_seq = {i: j for i, j in enumerate(object_x_seq)}

        return render(request, self.template_name, {
            'mid': object_one.mid,
            'date': object_date,
            'paid': object_one.paid,
            'tar_id': object_one.tar_id.tar_id,
            'tar_name': object_one.tar_id.tar_name,
            'clone_name': object_one.clone_name,
            'primer': object_one.primer,
            'direction': object_one.direction,
            'VH_code': object_one.VH_code,
            'VL_code': object_one.VL_code,
            'count_x': object_one.count_x,
            'protein_seq_x': object_x_seq,
            'group': object_one.group,
        })


# screening search
class screening_search_view(LoginRequiredMixin, FormView):

    form_class = screening_searchForm
    template_name = 'screening_analysis/screening_search.html'


    def form_valid(self, form):
        searchWord = form.cleaned_data['search_word']
        choice = form.data.get('TableID')


        if choice == 'SA':
            # iexact 는 대소문자 구분 없이 검색할 수 있도록 함.
            choice_list = screening_SA.objects.filter(Q(sid__icontains=searchWord)|
                                                      Q(tar_id__icontains=searchWord)|
                                                      Q(tar_name__icontains=searchWord)|
                                                      Q(sa_name__icontains=searchWord)|
                                                      Q(isoheavy__icontains=searchWord)|
                                                      Q(isolight__icontains=searchWord)
                                                      ).distinct()

            # head_list 를 만들어서 context 변수로 사용,
            # html에서 for 문으로 해당 내용을 사용
            head = 'SA'

        elif choice == 'AG':
            choice_list = screening_AG.objects.filter(Q(agid__icontains=searchWord)|
                                                      Q(date__icontains=searchWord)|
                                                      Q(constructor__icontains=searchWord)|
                                                      Q(user__icontains=searchWord)|
                                                      Q(ag_name__icontains=searchWord)|
                                                      Q(gene__icontains=searchWord)|
                                                      Q(fid__icontains=searchWord)|
                                                      Q(vector__icontains=searchWord)|
                                                      Q(ld__icontains=searchWord)
                                                      ).distinct()

            head = 'AG'

        elif choice == 'MID':
            choice_list = screening_ab1_database.objects.filter(Q(mid__icontains=searchWord)|
                                                                Q(date__icontains=searchWord)|
                                                                Q(paid__icontains=searchWord)|
                                                                Q(tar_id__tar_id__icontains=searchWord)|
                                                                Q(tar_id__tar_name__icontains=searchWord)|
                                                                Q(clone_name__icontains=searchWord)|
                                                                Q(primer__icontains=searchWord)|
                                                                Q(direction__icontains=searchWord)|
                                                                Q(user__username__icontains=searchWord)|
                                                                Q(status__icontains=searchWord)|
                                                                Q(group__icontains=searchWord)
                                                                ).distinct()

            head = 'MID'

        else:

            pass

        context = {}
        context['form'] = form
        context['search_term'] = searchWord
        context['object_list'] = choice_list
        context['head'] = head

        return render(self.request, self.template_name, context)
