from django.apps import AppConfig


class ScreeningAnalysisConfig(AppConfig):
    name = 'screening_analysis'
