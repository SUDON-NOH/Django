from django import forms


class screening_ab1_Form(forms.Form):
    file_field = forms.FileField(widget=forms.ClearableFileInput(attrs={'multiple': True}))


class screening_searchForm(forms.Form):
    search_word = forms.CharField(label='Search Word')
